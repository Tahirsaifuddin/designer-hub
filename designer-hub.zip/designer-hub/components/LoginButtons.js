"use client";
import { signIn } from "next-auth/react";
const b = { padding: "12px 18px", borderRadius: 6, border: "1px solid #ccc", fontSize: 16, fontWeight: 600, cursor: "pointer" };
export default function LoginButtons() {
  return (
    <div style={{ display: "flex", gap: 12, flexWrap: "wrap" }}>
      <button style={{ ...b, background: "#0a66c2", color: "#fff", border: 0 }} onClick={() => signIn("linkedin", { callbackUrl: "/dashboard" })}>Continue with LinkedIn</button>
      <button style={{ ...b, background: "#fff", color: "#222" }} onClick={() => signIn("google", { callbackUrl: "/dashboard" })}>Continue with Google</button>
    </div>
  );
}
