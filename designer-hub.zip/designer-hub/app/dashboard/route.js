import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import fs from "fs";
import path from "path";

export const dynamic = "force-dynamic";

export async function GET(req) {
  const session = await getServerSession(authOptions);
  if (!session) return Response.redirect(new URL("/", req.url));
  const name = session.user?.name || session.user?.email || "Designer";
  let html = fs.readFileSync(path.join(process.cwd(), "private", "dashboard.html"), "utf-8");
  const safe = JSON.stringify(name).replace(/</g, "\\u003c");
  html = html.replace("</head>", `<script>window.__USER__=${safe}</script></head>`);
  return new Response(html, { headers: { "content-type": "text/html; charset=utf-8" } });
}
