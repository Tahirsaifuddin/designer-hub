import { getServerSession } from "next-auth";
import { redirect } from "next/navigation";
import { authOptions } from "@/lib/auth";
import LoginButtons from "@/components/LoginButtons";

export default async function Home() {
  const session = await getServerSession(authOptions);
  if (session) redirect("/dashboard");
  return (
    <main style={{ maxWidth: 520, margin: "10vh auto", padding: 24 }}>
      <h1 style={{ fontFamily: "Georgia, serif", fontSize: 36 }}>Designer Hub</h1>
      <p>Check your LinkedIn profile, get post ideas every 3 days and manage client messages.</p>
      <LoginButtons />
    </main>
  );
}
