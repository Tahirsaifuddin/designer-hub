export const metadata = { title: "Designer Hub" };
export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body style={{ margin: 0, fontFamily: "system-ui, sans-serif", background: "#eef1f6", color: "#14213d" }}>
        {children}
      </body>
    </html>
  );
}
